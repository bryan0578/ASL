

</div>
<div class="row">
	<div class="span12">
		<div class="footer_bckg">
			<center><h4>Copyright &copy; Bryan Cash</h4></center>
		</div>
	</div>
</div>
</body>
</html>