<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.min.css" />
		
		<link href="<?php echo base_url() ?>css/style.css" rel="stylesheet" type="text/css">
	</head>
	<title>Welcome</title>
<body>
	<div class="header">
		<h1>Your Inventory</h1>
	</div>
	<div class="container">
		
		



