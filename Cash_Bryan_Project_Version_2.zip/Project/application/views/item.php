<div class="item">
    <div class="name_item">
        <?php echo html_escape($item->item_name); ?>
        #<?php echo html_escape($item->item_price); ?>
    </div>
    
</div>