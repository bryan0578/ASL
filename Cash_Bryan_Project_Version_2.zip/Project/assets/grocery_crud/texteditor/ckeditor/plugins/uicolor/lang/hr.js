﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('uicolor','hr',{uicolor:{title:'UI odabir boja',preview:'Pregled uživo',config:'Zalijepite ovaj tekst u Vašu config.js datoteku.',predefined:'Već postavljeni setovi boja'}});
